﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Title] VARCHAR(50) NOT NULL, 
    [Price] MONEY NULL, 
    [Date] DATETIME NULL, 
    [Rating] INT NULL
)
