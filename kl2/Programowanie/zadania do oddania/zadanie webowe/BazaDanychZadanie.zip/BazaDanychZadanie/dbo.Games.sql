﻿CREATE TABLE [dbo].[Games] (
    [Id]     INT             NOT NULL,
    [Title]  VARCHAR (50)    NOT NULL,
    [Price]  DECIMAL (10, 2) NULL,
    [Date]   DATETIME        NULL,
    [Rating] INT             NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

