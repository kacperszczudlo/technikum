using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using BazaDanychZadanie.Models;

namespace BazaDanychZadanie.Pages
{
    public class editGameModel : PageModel
    {
        [BindProperty]
        public Game MyGame { get; set; }
        private IConfiguration configuration;
        private string connString;

        public editGameModel(IConfiguration configuration)
        {
            this.configuration = configuration;
            connString = configuration["ConnectionStrings:DefaultConnection"];

        }
        public IActionResult OnGet(int? id = null)
        {
            if (id == null) return RedirectToPage("Index");
            using (SqlConnection connection = new SqlConnection(connString))
            {
                SqlCommand command = connection.CreateCommand();
                string sql = "SELECT Id,Title,Price,Date,Rating from Games WHERE Id=@GameId";
                SqlParameter parameter = new SqlParameter
                {
                    ParameterName = "@GameId",
                    Value = id,
                    SqlDbType = SqlDbType.Int
                };
                command.Parameters.Add(parameter);
                command.CommandText = sql;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    MyGame = new Game
                    {
                        Id = reader.GetInt32(0),
                        Title = reader.GetString(1),
                        Price = reader.GetDecimal(2),
                        Date = reader.GetDateTime(3),
                        Rating = reader.GetInt32(4),
                    };
                }
                connection.Close();
            }
            return Page();
        }

        public IActionResult OnPost(int id)
        {
            if (ModelState.IsValid)
            {
                ViewData["info"] = "OK";
                using (SqlConnection connection = new SqlConnection(connString))
                {
                    string sql = "UPDATE Games SET Title=@Title, Price=@Price, Date=@Date, Rating=@Rating WHERE Id=@GameId";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        SqlParameter parameter1 = new SqlParameter
                        {
                            ParameterName = "@Title",
                            Value = MyGame.Title,
                            SqlDbType = SqlDbType.NVarChar,
                            Size = 50
                        };
                        command.Parameters.Add(parameter1);
                        SqlParameter parameter2 = new SqlParameter
                        {
                            ParameterName = "@Price",
                            Value = MyGame.Price,
                            SqlDbType = SqlDbType.Decimal,
                        };
                        command.Parameters.Add(parameter2);
                        SqlParameter parameter3 = new SqlParameter
                        {
                            ParameterName = "@Date",
                            Value = MyGame.Date,
                            SqlDbType = SqlDbType.Date
                        };
                        command.Parameters.Add(parameter3);
                        SqlParameter parameter4 = new SqlParameter
                        {
                            ParameterName = "@Rating",
                            Value = MyGame.Rating,
                            SqlDbType = SqlDbType.Int
                        };
                        command.Parameters.Add(parameter4);
                        SqlParameter parameter5 = new SqlParameter
                        {
                            ParameterName = "@GameId",
                            Value = id,
                            SqlDbType = SqlDbType.Int
                        };
                        command.Parameters.Add(parameter5);
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }
                }

            }
            else
            {
                ViewData["info"] = "B��d!";
            }

            return RedirectToPage("Index");
        }

    }
}
