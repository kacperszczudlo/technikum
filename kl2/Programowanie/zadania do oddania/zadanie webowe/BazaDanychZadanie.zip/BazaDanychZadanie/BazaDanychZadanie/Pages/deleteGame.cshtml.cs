using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;

namespace BazaDanychZadanie.Pages
{
    public class deleteGameModel : PageModel
    {
        private IConfiguration configuration;
        private string connString;
        public deleteGameModel(IConfiguration configuration)
        {
            this.configuration = configuration;
            connString = configuration["ConnectionStrings:DefaultConnection"];
        }
        public IActionResult OnGet(int? id = null)
        {
            if (id == null) return RedirectToPage("Index");
            int gameId = (int)id;
            using (SqlConnection connection = new SqlConnection(connString))
            {
                using (SqlCommand command = connection.CreateCommand())
                {
                    string sql = $"DELETE FROM Games WHERE Id={gameId}";
                    command.CommandType = CommandType.Text;
                    command.CommandText = sql;
                    connection.Open();
                    var result = command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return RedirectToPage("Index");
        }
    }
}
