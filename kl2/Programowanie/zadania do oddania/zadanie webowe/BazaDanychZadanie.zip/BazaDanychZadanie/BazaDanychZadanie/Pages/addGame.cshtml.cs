using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using BazaDanychZadanie.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;

namespace BazaDanychZadanie.Pages
{
    public class addGameModel : PageModel
    {
        [BindProperty] public Game MyGame { get; set; }

        private IConfiguration configuration;
        private string connString;
        private SqlConnection connection;

        public addGameModel(IConfiguration configuration)
        {
            this.configuration = configuration;
            connString = configuration["ConnectionStrings:DefaultConnection"];
        }

        public void OnPost()
        {
            if (ModelState.IsValid)
            {
                connection = new SqlConnection(connString);

                string sql = $"INSERT INTO Games(Title,Price,Date,Rating) VALUES(N'{MyGame.Title}',{MyGame.Price},'{MyGame.Date}',{MyGame.Rating})";

                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.CommandType = CommandType.Text;
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
                ViewData["Info"] = "Zapisano do bazy danych";
            }
            else
            {
                ViewData["Info"] = "B��dne dane";
            }
        }
    }
}
