﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using BazaDanychZadanie.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace BazaDanychZadanie.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public List<Game> Games { get; set; }

        private IConfiguration configuration;
        private string connString;
        private SqlConnection connection;

        public IndexModel(IConfiguration configuration)
        {
            this.configuration = configuration;
            connString = configuration["ConnectionStrings:DefaultConnection"];
        }

        public void OnGet()
        {
            connection = new SqlConnection(connString);
            Games = getAllGames(connection);
        }

        private List<Game> getAllGames(SqlConnection connection)
        {
            List<Game> games = new List<Game>();
            SqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT Id,Title,Price,Date,Rating FROM Games";
            connection.Open();
            SqlDataReader dr = command.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    games.Add(new Game
                    {
                        Id = dr.GetInt32(0),
                        Title = dr.GetString(1),
                        Price = dr.GetDecimal(2),
                        Date = dr.GetDateTime(3),
                        Rating = dr.GetInt32(4),
                    }) ;
                }
            }
            connection.Close();
            return games;
        }
    }
}
