﻿
using Microsoft.OData.Edm;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BazaDanychZadanie.Models
{
    public class Game
    {
        public int Id { get; set; }
        
        [Display(Name = "Nazwa Gry")]
        [Required]
        public string Title { get; set; }

        [Display(Name = "Cena")]
        [Required]
        public decimal Price { get; set; }

        [Display(Name = "Data wydania")]
        [Required]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime Date { get; set; }

        [Display(Name = "Ocena")]
        [Required]
        public int Rating { get; set; }
    }
}
